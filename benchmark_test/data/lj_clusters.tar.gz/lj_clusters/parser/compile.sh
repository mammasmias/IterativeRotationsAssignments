gfortran -o parser.x parser.f90
