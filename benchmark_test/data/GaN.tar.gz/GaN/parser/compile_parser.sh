gfortran -fdefault-real-8 -o parser.x parser.f90
